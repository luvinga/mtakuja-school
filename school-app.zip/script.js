// Navigation function
function goTo(url) {
    window.location.href = url;
}

function goBack() {
    window.history.back();
}

// Students list
let students = ["Student 1", "Student 2", "Student 3", "Student 4", "Student 5"];
let attendance = {};

// Attendance functions
function mark(student, status) {
    attendance[student] = status;
    alert(student + " marked as " + status);
    // Update UI if needed
}

function saveAttendance() {
    let date = new Date().toISOString().split('T')[0];
    let record = { date, attendance: {...attendance} };
    let records = JSON.parse(localStorage.getItem('attendanceRecords') || '[]');
    records.push(record);
    localStorage.setItem('attendanceRecords', JSON.stringify(records));
    alert("Attendance Saved!");
    attendance = {}; // reset for next day
}

// Grades function
let grades = {};

function saveGrades() {
    let inputs = document.querySelectorAll('#grades-list input');
    students.forEach((student, index) => {
        grades[student] = inputs[index].value;
    });
    let date = new Date().toISOString().split('T')[0];
    let record = { date, grades: {...grades} };
    let records = JSON.parse(localStorage.getItem('gradesRecords') || '[]');
    records.push(record);
    localStorage.setItem('gradesRecords', JSON.stringify(records));
    alert("Grades Saved!");
    grades = {};
}

// View student profile
function viewProfile(student) {
    alert("Viewing profile of " + student);
}
